const CACHE_NAME = "dermanio-v5";
const APP_SHELL = [
  "/static/css/style.css",
  "/static/js/app.js",
  "/static/icons/icon-192.png",
  "/static/icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// استراتژی: برای فایل‌های ثابت (CSS/JS/آیکون) از کش استفاده کن، برای بقیه درخواست‌ها از شبکه
// (چون داده‌های پزشکی/مالی باید همیشه به‌روز باشند، صفحات HTML کش نمی‌شوند)
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (APP_SHELL.some((path) => url.pathname === path)) {
    event.respondWith(
      caches.match(event.request).then((cached) => cached || fetch(event.request))
    );
  }
});
