(function () {
  'use strict';

  // Reliable Jalali <-> Gregorian conversion.
  // This implementation is independent of browser locale/timezone and is
  // tested for modern dates such as Gregorian 2026/09/08 = Jalali 1405/06/17.
  function div(a,b){ return Math.floor(a/b); }
  function rem(a,b){ return a - div(a,b)*b; }
  var gDays=[31,28,31,30,31,30,31,31,30,31,30,31];
  var jDays=[31,31,31,31,31,31,30,30,30,30,30,29];

  function g2j(gy0,gm0,gd0){
    var gy=gy0-1600, gm=gm0-1, gd=gd0-1;
    var gDayNo=365*gy+div(gy+3,4)-div(gy+99,100)+div(gy+399,400);
    for(var i=0;i<gm;i++) gDayNo+=gDays[i];
    if(gm>1 && ((gy0%4===0 && gy0%100!==0) || gy0%400===0)) gDayNo++;
    gDayNo+=gd;

    var jDayNo=gDayNo-79;
    var jNp=div(jDayNo,12053);
    jDayNo=rem(jDayNo,12053);
    var jy=979+33*jNp+4*div(jDayNo,1461);
    jDayNo=rem(jDayNo,1461);
    if(jDayNo>=366){
      jy+=div(jDayNo-1,365);
      jDayNo=rem(jDayNo-1,365);
    }
    var jm=0;
    while(jm<11 && jDayNo>=jDays[jm]){
      jDayNo-=jDays[jm];
      jm++;
    }
    return [jy,jm+1,jDayNo+1];
  }

  function j2g(jy0,jm0,jd0){
    var jy=jy0-979, jm=jm0-1, jd=jd0-1;
    var jDayNo=365*jy+div(jy,33)*8+div(rem(jy,33)+3,4);
    for(var i=0;i<jm;i++) jDayNo+=jDays[i];
    jDayNo+=jd;

    var gDayNo=jDayNo+79;
    var gy=1600+400*div(gDayNo,146097);
    gDayNo=rem(gDayNo,146097);
    var leap=true;
    if(gDayNo>=36525){
      gDayNo--;
      gy+=100*div(gDayNo,36524);
      gDayNo=rem(gDayNo,36524);
      if(gDayNo>=365) gDayNo++; else leap=false;
    }
    gy+=4*div(gDayNo,1461);
    gDayNo=rem(gDayNo,1461);
    if(gDayNo>=366){
      leap=false;
      gDayNo--;
      gy+=div(gDayNo,365);
      gDayNo=rem(gDayNo,365);
    }
    var gm=0;
    while(gDayNo >= gDays[gm] + ((gm===1 && leap)?1:0)){
      gDayNo-=gDays[gm] + ((gm===1 && leap)?1:0);
      gm++;
    }
    return [gy,gm+1,gDayNo+1];
  }

  function j2d(jy,jm,jd){
    var g=j2g(jy,jm,jd);
    return Math.floor(Date.UTC(g[0],g[1]-1,g[2])/86400000);
  }
  function todayJ(){
    var n=new Date();
    return g2j(n.getFullYear(),n.getMonth()+1,n.getDate());
  }
  function weekdayOfJalali(y,m,d){
    var g=j2g(y,m,d);
    return new Date(g[0],g[1]-1,g[2]).getDay();
  }

  function pad(n){ return String(n).padStart(2,'0'); }

  function parse(value){
    var m=String(value||'').trim().match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
    if(!m) return null;
    var y=+m[1], mo=+m[2], d=+m[3];
    if(y<1 || mo<1 || mo>12) return null;
    var max=daysInMonth(y,mo);
    if(d<1 || d>max) return null;
    return [y,mo,d];
  }

  function daysInMonth(y,m){
    if(m<=6) return 31;
    if(m<=11) return 30;
    // Calculate Esfand length from the conversion routine rather than
    // assuming a fixed leap-year cycle.
    var first=j2d(y,12,1);
    var next=j2d(y+1,1,1);
    return next-first;
  }

  var monthNames=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
  var week=['ش','ی','د','س','چ','پ','ج'];
  var active=null;
  var picker=null;
  var repositionHandler=null;

  function closePicker(){
    if(active) active.setAttribute('aria-expanded','false');
    if(picker) picker.remove();
    if(repositionHandler){ window.removeEventListener('resize',repositionHandler); window.removeEventListener('scroll',repositionHandler,true); }
    picker=null; active=null; repositionHandler=null;
  }

  function openPicker(input){
    closePicker();
    active=input;
    var current=parse(input.value) || todayJ();
    var val=[current[0],current[1],current[2]];
    picker=document.createElement('div');
    picker.className='jalali-picker';
    picker.innerHTML=''
      +'<div class="jp-head">'
      +'<button type="button" class="jp-prev" aria-label="ماه قبل">‹</button>'
      +'<div class="jp-selectors"><select class="jp-month" aria-label="ماه"></select><select class="jp-year" aria-label="سال"></select></div>'
      +'<button type="button" class="jp-next" aria-label="ماه بعد">›</button>'
      +'</div>'
      +'<div class="jp-week"></div><div class="jp-grid"></div>'
      +'<div class="jp-foot"><button type="button" class="jp-today">امروز</button><button type="button" class="jp-clear">پاک کردن</button></div>';
    document.body.appendChild(picker);
    input.setAttribute('aria-expanded','true');

    var monthSelect=picker.querySelector('.jp-month');
    var yearSelect=picker.querySelector('.jp-year');
    monthNames.forEach(function(name,i){ monthSelect.add(new Option(name,String(i+1))); });
    for(var y=1290;y<=1450;y++) yearSelect.add(new Option(String(y),String(y)));

    monthSelect.onchange=function(){ val[1]=+this.value; val[2]=Math.min(val[2],daysInMonth(val[0],val[1])); render(); };
    yearSelect.onchange=function(){ val[0]=+this.value; val[2]=Math.min(val[2],daysInMonth(val[0],val[1])); render(); };
    picker.querySelector('.jp-prev').onclick=function(){ val[1]--; if(val[1]<1){val[1]=12;val[0]--;} val[2]=Math.min(val[2],daysInMonth(val[0],val[1])); render(); };
    picker.querySelector('.jp-next').onclick=function(){ val[1]++; if(val[1]>12){val[1]=1;val[0]++;} val[2]=Math.min(val[2],daysInMonth(val[0],val[1])); render(); };
    picker.querySelector('.jp-today').onclick=function(){ var t=todayJ(); val=[t[0],t[1],t[2]]; choose(val); };
    picker.querySelector('.jp-clear').onclick=function(){ input.value=''; closePicker(); input.dispatchEvent(new Event('change',{bubbles:true})); input.focus(); };

    function choose(v){
      input.value=v[0]+'/'+pad(v[1])+'/'+pad(v[2]);
      closePicker();
      input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    function render(){
      monthSelect.value=String(val[1]); yearSelect.value=String(val[0]);
      picker.querySelector('.jp-week').innerHTML=week.map(function(x){return '<span>'+x+'</span>';}).join('');
      // g2d() is a Julian day number. JDN 0 is Monday, so convert to JS Sunday=0.
      var jsDay=weekdayOfJalali(val[0],val[1],1);
      var offset=(jsDay+1)%7;
      var html='';
      for(var i=0;i<offset;i++) html+='<span class="jp-empty"></span>';
      var max=daysInMonth(val[0],val[1]), selected=parse(input.value);
      for(var d=1;d<=max;d++){
        var cls=(selected&&selected[0]===val[0]&&selected[1]===val[1]&&selected[2]===d)?' jp-selected':'';
        html+='<button type="button" class="jp-day'+cls+'" data-day="'+d+'">'+d+'</button>';
      }
      picker.querySelector('.jp-grid').innerHTML=html;
      picker.querySelectorAll('.jp-day').forEach(function(b){ b.onclick=function(){ choose([val[0],val[1],+b.dataset.day]); }; });
      position();
    }
    function position(){
      if(!picker || !active) return;
      var r=active.getBoundingClientRect();
      var h=picker.offsetHeight, w=picker.offsetWidth;
      var left=r.left+window.scrollX+r.width-w;
      var top=r.bottom+window.scrollY+6;
      if(left<8) left=8;
      if(left+w>window.innerWidth+window.scrollX-8) left=window.innerWidth+window.scrollX-w-8;
      if(r.bottom+h>window.innerHeight) top=Math.max(8+window.scrollY,r.top+window.scrollY-h-6);
      picker.style.top=top+'px'; picker.style.left=left+'px';
    }
    repositionHandler=position;
    window.addEventListener('resize',repositionHandler);
    window.addEventListener('scroll',repositionHandler,true);
    render();
  }

  function init(){
    document.querySelectorAll('input.jalali-date').forEach(function(input){
      if(input.dataset.jpReady) return;
      input.dataset.jpReady='1';
      input.setAttribute('autocomplete','off');
      input.setAttribute('aria-haspopup','dialog');
      input.setAttribute('aria-expanded','false');
      input.addEventListener('click',function(){ openPicker(input); });
      input.addEventListener('focus',function(){ openPicker(input); });
      input.addEventListener('input',function(){
        var pos=input.selectionStart;
        var clean=input.value.replace(/[^0-9/\-]/g,'').replace(/-/g,'/');
        if(clean!==input.value) input.value=clean;
      });
      input.addEventListener('keydown',function(e){ if(e.key==='Escape') closePicker(); });
    });
    document.addEventListener('mousedown',function(e){
      if(active && !e.target.closest('.jalali-picker') && !e.target.closest('input.jalali-date')) closePicker();
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
