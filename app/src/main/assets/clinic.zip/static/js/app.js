// ثبت سرویس‌ورکر برای قابلیت نصب (PWA) روی موبایل و PC
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('/service-worker.js').catch(function (err) {
      console.warn('Service worker registration failed:', err);
    });
  });
}

// چک‌باکس‌های آیتم‌های مالی در فرم صورتحساب
document.addEventListener('DOMContentLoaded', function () {
  // با تیک خوردن هر آیتم، کادر مبلغ همان ردیف فعال/غیرفعال می‌شود
  document.querySelectorAll('.service-item-toggle').forEach(function (toggle) {
    toggle.addEventListener('change', function () {
      var row = toggle.closest('.service-item-row');
      var descInput = row.querySelector('.service-item-desc');
      var amountInput = row.querySelector('.service-item-amount');
      if (toggle.checked) {
        descInput.disabled = false;
        amountInput.disabled = false;
        row.classList.add('is-checked');
        amountInput.focus();
      } else {
        descInput.disabled = true;
        amountInput.disabled = true;
        row.classList.remove('is-checked');
      }
    });
  });

  // ردیف «سایر»: با تیک خوردن، هم کادر عنوان و هم کادر مبلغ باز می‌شود
  var otherToggle = document.getElementById('service-item-other-toggle');
  var otherNameInput = document.getElementById('service-item-other-name');
  var otherAmountInput = document.getElementById('service-item-other-amount');
  if (otherToggle && otherNameInput && otherAmountInput) {
    otherToggle.addEventListener('change', function () {
      var row = otherToggle.closest('.service-item-row');
      if (otherToggle.checked) {
        otherNameInput.disabled = false;
        otherAmountInput.disabled = false;
        row.classList.add('is-checked');
        otherNameInput.focus();
      } else {
        otherNameInput.disabled = true;
        otherAmountInput.disabled = true;
        otherNameInput.value = '';
        otherAmountInput.value = '';
        row.classList.remove('is-checked');
      }
    });
  }
});

// جداکننده سه‌رقمی (۳تا۳تا) برای فیلدهای مبلغ هنگام تایپ
document.addEventListener('input', function (e) {
  if (e.target && e.target.classList && e.target.classList.contains('money-input')) {
    var digits = e.target.value.replace(/[^0-9]/g, '');
    e.target.value = digits ? Number(digits).toLocaleString('en-US') : '';
    e.target.classList.remove('input-error');
  }
});

// حذف جداکننده‌ها قبل از ارسال فرم تا مقدار عددی خام به سرور برسد
// و اطمینان از اینکه هر آیتم تیک‌خورده، مبلغ هم داشته باشد
document.addEventListener('submit', function (e) {
  var form = e.target;
  if (!form || !form.querySelectorAll) {
    return;
  }

  var missingAmount = false;
  form.querySelectorAll('.service-item-toggle:checked, #service-item-other-toggle:checked').forEach(function (toggle) {
    var row = toggle.closest('.service-item-row');
    var amountInput = row.querySelector('.service-item-amount, .money-input');
    if (amountInput && !amountInput.value.trim()) {
      missingAmount = true;
      amountInput.classList.add('input-error');
    }
  });
  if (missingAmount) {
    e.preventDefault();
    alert('برای آیتم‌هایی که تیک زده‌اید، مبلغ را هم وارد کنید.');
    return;
  }

  form.querySelectorAll('.money-input').forEach(function (input) {
    input.value = input.value.replace(/,/g, '');
  });
});
